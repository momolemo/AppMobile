/** Automatically generated file. DO NOT MODIFY */
package fr.polytech.bonscomptes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}